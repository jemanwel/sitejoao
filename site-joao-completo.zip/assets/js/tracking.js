/* tracking.js — estrutura de eventos de conversão.
 *
 * Cada CTA de WhatsApp é um link nativo (funciona sem JS). Este arquivo apenas
 * registra o clique como evento, identificando a seção de origem. GA4 e Google
 * Ads entram depois como tags, consumindo o dataLayer — nada aqui precisa mudar.
 *
 * Limite conhecido: o clique mede a ação no site, não comprova conversa nem
 * agendamento. Fechar esse ciclo depende do retorno do atendimento ou do CRM.
 */
(function () {
  "use strict";

  window.dataLayer = window.dataLayer || [];

  function registrarClique(el) {
    var secao = el.getAttribute("data-cta-section") || "desconhecida";
    var rotulo = (el.textContent || "").trim();

    window.dataLayer.push({
      event: "whatsapp_click",
      cta_section: secao,
      cta_label: rotulo
    });

    if (typeof window.gtag === "function") {
      window.gtag("event", "generate_lead", {
        method: "whatsapp",
        cta_section: secao,
        cta_label: rotulo
      });
    }
  }

  // Delegação: cobre também os CTAs das seções construídas depois.
  document.addEventListener(
    "click",
    function (evento) {
      var el = evento.target.closest("[data-cta]");
      if (el) {
        registrarClique(el);
      }
    },
    { passive: true }
  );
})();

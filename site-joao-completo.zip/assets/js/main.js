/* main.js — comportamentos de interface.
   Reveal de rolagem progressivo: sem JS, tudo visível; com JS, entrada suave
   uma vez. Respeita prefers-reduced-motion. Sem dependências.

   Robustez (o conteúdo NUNCA pode ficar preso invisível):
   - só elementos "up" e os filhos de "stagger" partem ocultos (ver CSS);
   - qualquer falha (sem IntersectionObserver, erro, aba oculta) revela tudo;
   - rede de segurança por tempo revela o que sobrar, por garantia. */
(function () {
  "use strict";

  var docEl = document.documentElement;
  docEl.classList.add("js"); /* redundante com o inline do <head>, por garantia */

  function revealEverything() {
    var pending = document.querySelectorAll(
      '[data-reveal="up"]:not(.is-visible), [data-reveal="stagger"] > *:not(.is-visible)'
    );
    for (var i = 0; i < pending.length; i++) {
      pending[i].style.transitionDelay = "0ms";
      pending[i].classList.add("is-visible");
    }
  }

  try {
    var ups = Array.prototype.slice.call(
      document.querySelectorAll('[data-reveal="up"]')
    );
    var groups = Array.prototype.slice.call(
      document.querySelectorAll('[data-reveal="stagger"]')
    );

    var reduce =
      window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function showGroup(el) {
      var kids = el.children;
      for (var i = 0; i < kids.length; i++) {
        /* cascata curta e contida — nunca deixa o último item esperar demais */
        kids[i].style.transitionDelay = Math.min(i, 6) * 80 + "ms";
        kids[i].classList.add("is-visible");
      }
    }

    /* Sem IntersectionObserver ou com movimento reduzido: revela tudo já. */
    if (reduce || !("IntersectionObserver" in window)) {
      revealEverything();
      return;
    }

    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var el = entry.target;
          io.unobserve(el);
          if (el.getAttribute("data-reveal") === "stagger") {
            showGroup(el);
          } else {
            el.classList.add("is-visible");
          }
        });
      },
      { rootMargin: "0px 0px -10% 0px", threshold: 0.12 }
    );

    ups.forEach(function (el) {
      io.observe(el);
    });
    groups.forEach(function (el) {
      io.observe(el);
    });

    /* Rede de segurança: garante que nenhuma seção fique invisível caso o
       observer, por qualquer motivo, não dispare para um elemento em tela. */
    window.setTimeout(revealEverything, 4000);
    window.addEventListener("error", revealEverything, { once: true });
  } catch (e) {
    revealEverything();
  }
})();

/* ------------------------------------------------------------------
   Parallax sutil — SÓ nas camadas de imagem (nunca no texto). Escala
   leve + deslocamento contido, para dar profundidade/dinamismo sem
   prejudicar a leitura. Respeita prefers-reduced-motion. Sem deps.
------------------------------------------------------------------ */
(function () {
  "use strict";

  var reduce =
    window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  /* Parallax só em ponteiro fino (desktop). No toque, scroll-parallax
     trepida e custa performance — a foto fica estática, sem jank. */
  var coarse =
    window.matchMedia &&
    window.matchMedia("(hover: none), (pointer: coarse)").matches;
  var items = Array.prototype.slice.call(
    document.querySelectorAll("[data-parallax]")
  );
  if (reduce || coarse || !items.length || !("requestAnimationFrame" in window))
    return;

  var SCALE = 1.14; /* zoom base — folga suficiente para o deslocamento */
  var RANGE = 0.045; /* ±4,5% da altura do elemento (dentro da folga) */
  var vh = window.innerHeight || document.documentElement.clientHeight;
  var ticking = false;

  function apply(el) {
    var rect = el.getBoundingClientRect();
    if (rect.bottom < -160 || rect.top > vh + 160) return;
    var center = rect.top + rect.height / 2;
    var frac = (center - vh / 2) / (vh / 2 + rect.height / 2);
    if (frac > 1) frac = 1;
    if (frac < -1) frac = -1;
    var offset = -frac * (rect.height * RANGE);
    el.style.transform =
      "translate3d(0," + offset.toFixed(1) + "px,0) scale(" + SCALE + ")";
  }
  function update() {
    ticking = false;
    for (var i = 0; i < items.length; i++) apply(items[i]);
  }
  function onScroll() {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(update);
    }
  }

  for (var i = 0; i < items.length; i++) {
    items[i].style.willChange = "transform";
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener(
    "resize",
    function () {
      vh = window.innerHeight || document.documentElement.clientHeight;
      onScroll();
    },
    { passive: true }
  );
  update();
})();

/* ------------------------------------------------------------------
   Cards com inclinação magnética + luz que segue o cursor. Só em
   ponteiro fino (mouse) e sem movimento reduzido. A luz e o recuo do
   irmão em foco vivem no CSS; aqui só alimentamos --mx/--my/--glow e a
   inclinação sutil (máx. 5°). rAF-throttled. Sem dependências.
------------------------------------------------------------------ */
(function () {
  "use strict";
  if (!window.matchMedia) return;

  var fine = window.matchMedia("(hover: hover) and (pointer: fine)");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (!fine.matches || reduce.matches) return;
  if (!("requestAnimationFrame" in window)) return;

  var cards = Array.prototype.slice.call(
    document.querySelectorAll("[data-tilt]")
  );
  if (!cards.length) return;

  var MAX = 5; /* graus de inclinação — contido, executivo */

  cards.forEach(function (card) {
    var rect = null;
    var raf = 0;
    var lastX = 0;
    var lastY = 0;

    function paint() {
      raf = 0;
      if (!rect) return;
      var px = (lastX - rect.left) / rect.width;
      var py = (lastY - rect.top) / rect.height;
      if (px < 0) px = 0;
      else if (px > 1) px = 1;
      if (py < 0) py = 0;
      else if (py > 1) py = 1;
      var ry = (px - 0.5) * (MAX * 2);
      var rx = (0.5 - py) * (MAX * 2);
      card.style.setProperty("--mx", (px * 100).toFixed(1) + "%");
      card.style.setProperty("--my", (py * 100).toFixed(1) + "%");
      card.style.setProperty("--glow", "1");
      card.style.transform =
        "perspective(900px) rotateX(" +
        rx.toFixed(2) +
        "deg) rotateY(" +
        ry.toFixed(2) +
        "deg)";
    }

    card.addEventListener("pointerenter", function () {
      rect = card.getBoundingClientRect();
    });
    card.addEventListener(
      "pointermove",
      function (e) {
        lastX = e.clientX;
        lastY = e.clientY;
        if (!rect) rect = card.getBoundingClientRect();
        if (!raf) raf = window.requestAnimationFrame(paint);
      },
      { passive: true }
    );
    card.addEventListener("pointerleave", function () {
      rect = null;
      if (raf) {
        window.cancelAnimationFrame(raf);
        raf = 0;
      }
      card.style.setProperty("--glow", "0");
      card.style.transform = ""; /* volta ao repouso via transition do CSS */
    });
  });
})();

/* ------------------------------------------------------------------
   Flip cards. No desktop (hover real) o CSS vira no hover/foco. No
   toque, alterna .is-flipped no tap. Teclado alterna com Enter/Espaço.
   Sem dependências, sem custo contínuo.
------------------------------------------------------------------ */
(function () {
  "use strict";
  var cards = Array.prototype.slice.call(
    document.querySelectorAll("[data-flip]")
  );
  if (!cards.length) return;

  /* Só o desktop com hover fino conta com o virar-no-hover do CSS. Em
     qualquer outro aparelho (celular, tablet, híbrido, ou se a detecção
     de hover falhar) o tap alterna o flip — mais robusto que testar por
     "coarse", que alguns aparelhos reportam errado. */
  var fineHover =
    window.matchMedia &&
    window.matchMedia("(hover: hover) and (pointer: fine)").matches;

  cards.forEach(function (card) {
    if (!fineHover) {
      card.addEventListener("click", function () {
        card.classList.toggle("is-flipped");
      });
    }
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " " || e.key === "Spacebar") {
        e.preventDefault();
        card.classList.toggle("is-flipped");
      }
    });
  });
})();

/* ------------------------------------------------------------------
   Count-up dos números-chave (prejuízo). Sem biblioteca: rAF + ease-out.
   O valor final já está no HTML — sem JS, aparece correto. Com movimento
   reduzido, não anima. Rede de segurança finaliza tudo em 4s (mesma
   filosofia do reveal): nenhum número fica preso em zero.
------------------------------------------------------------------ */
(function () {
  "use strict";

  var els = Array.prototype.slice.call(
    document.querySelectorAll("[data-countup-to]")
  );
  if (!els.length) return;

  /* fonte da verdade = o texto final que já está no HTML */
  els.forEach(function (el) {
    el.setAttribute("data-countup-final", el.textContent.trim());
  });

  function finalize(el) {
    if (el.dataset.countupDone) return;
    el.dataset.countupDone = "1";
    el.textContent = el.getAttribute("data-countup-final");
  }

  var reduce =
    window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var canAnimate =
    !reduce &&
    "IntersectionObserver" in window &&
    "requestAnimationFrame" in window;

  /* Sem animação possível: mantém o valor final e sai. */
  if (!canAnimate) {
    els.forEach(finalize);
    return;
  }

  function fmt(v, decimals) {
    return v.toLocaleString("pt-BR", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  }
  function easeOut(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  function run(el) {
    if (el.dataset.countupDone) return;
    el.dataset.countupDone = "1";
    var to = parseFloat(el.getAttribute("data-countup-to"));
    var from = parseFloat(el.getAttribute("data-countup-from") || "0");
    var decimals = parseInt(
      el.getAttribute("data-countup-decimals") || "0",
      10
    );
    var DURATION = 1400;
    var startTs = null;

    function step(ts) {
      if (startTs === null) startTs = ts;
      var p = Math.min((ts - startTs) / DURATION, 1);
      el.textContent = fmt(from + (to - from) * easeOut(p), decimals);
      if (p < 1) {
        window.requestAnimationFrame(step);
      } else {
        /* trava no texto original exato (formatação da copy) */
        el.textContent = el.getAttribute("data-countup-final");
      }
    }
    window.requestAnimationFrame(step);
  }

  /* O valor final fica no DOM até o número entrar em tela; só então run()
     zera no 1º frame e conta — o fade-in do reveal mascara essa troca. Se o
     observer nunca disparar, o número simplesmente permanece correto (nunca
     preso em zero), então não é preciso rede de segurança por tempo. */
  var io = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        io.unobserve(entry.target);
        run(entry.target);
      });
    },
    { rootMargin: "0px 0px -5% 0px", threshold: 0 }
  );

  els.forEach(function (el) {
    io.observe(el);
  });

  window.addEventListener(
    "error",
    function () {
      els.forEach(finalize);
    },
    { once: true }
  );
})();

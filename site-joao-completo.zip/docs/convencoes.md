# Convenções — Site João Tufanini

Regras de código e design que valem para todas as seções. Consultar antes de
escrever qualquer coisa nova.

## CSS

- Três arquivos na ordem fixa do HTML: `base.css`, `components.css`, `sections.css`.
  Sem `@import`.
- Cascata por `@layer`. Ordem declarada em `base.css`:
  `reset, tokens, base, layout, components, sections, utilities`.
- **Sem `!important`.** Se precisar vencer especificidade, use a ordem de camadas
  (`utilities` é a última e vence). Foi assim que o reset de `prefers-reduced-motion`
  ficou sem `!important`.
- Classes em kebab-case, nomeadas por função (`.hero__credentials`), nunca por
  aparência (`.azul`, `.grande`).
- BEM leve: `bloco__elemento` e `bloco--modificador`.

## Cor

- Só os 6 tokens de `:root`. Não introduzir cinza neutro novo.
- Fios e bordas saem de `--hairline` / `--hairline-soft` (acento e texto com alpha),
  nunca de um cinza próprio.
- Elevação = trocar `--ink-900` por `--ink-800` (+ fio opcional). **Nunca sombra
  cinza.**
- Gradiente só como função (scrim de legibilidade sobre foto), nunca decoração.

## Tipografia

- Display (`--font-display`, Saira Condensed): só títulos e o número-destaque da
  seção 3. Caixa alta apenas aqui.
- Corpo e sub-heads (`--font-body`, IBM Plex Sans): caixa de frase.
- Corpo nunca abaixo de 16px. Contraste vem de peso/caixa/tracking/entrelinha,
  não de encolher o corpo.
- Sem rótulo em caixa alta com letter-spacing acima de cada heading. Linhas de
  contexto vão em caixa de frase, `--text-400`.

## Componentes

- Reutilizar `.btn`, `.cta`, `.credentials`, `.pull-quote`. Não recriar variações
  paralelas.
- Botão sem seta anexada. Raio pequeno (4px) reservado à ação; não repetir o mesmo
  raio em todo elemento.

## Acessibilidade

- Hierarquia de heading sem pular nível (um `<h1>`, seções em `<h2>`).
- Foco visível em tudo que é interativo (`:focus-visible`, acento).
- Contraste mínimo 4.5:1. Tokens já verificados: `--text-100` e `--text-400`
  passam sobre `--ink-900`.
- Todo CTA é link nativo e funciona com JavaScript desativado.

## Conversão e medição

- CTA = link `https://wa.me/5511997188324` com `?text=` pré-preenchido e
  **diferente por seção** (identifica a origem do lead na conversa).
- Marcar cada CTA com `data-cta` e `data-cta-section="<slug>"`. O `tracking.js`
  usa isso via delegação de evento.

## Imagens

- `width` e `height` explícitos sempre. Proporção travada por CSS (`aspect-ratio`).
- Placeholder com `data-final-src` e `data-min-size`. Hero nunca lazy; recebe
  `<link rel="preload">` quando o arquivo final entrar.

## Fluxo

- Uma etapa = uma seção (ou a fundação) = uma entrada em `decisoes.md` + um commit.
- Correção cirúrgica. Não refazer seção inteira por um detalhe.
- Nenhuma regra nova pode quebrar seção anterior. Validar em
  360 / 390 / 768 / 1024 / 1440 / 1920.

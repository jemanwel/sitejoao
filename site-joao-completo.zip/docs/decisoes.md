# Decisões — Site João Tufanini

Log de cada etapa concluída: o que foi feito e por quê. Consultar antes de cada
seção nova para não se contradizer.

---

## Etapa 0 — Fundação (2026-09-20)

**O que:** `git init`; estrutura de pastas; `base.css` (camadas, 6 tokens de cor,
tipografia base, primitivas de layout); `components.css` (cabeçalho, botão, CTA,
credenciais, pull-quote); `tracking.js` (estrutura de eventos); `docs/convencoes.md`.

**Por quê / decisões travadas:**
- **Paleta:** 6 tokens dentro da faixa da marca. Fios derivados de acento/texto
  com `color-mix`, sem cinza neutro. Elevação por `--ink-800`, nunca sombra.
- **Tipografia:** Saira Condensed (títulos) + IBM Plex Sans (corpo). Rejeitados
  Oswald/Bebas (clichê de pôster) e Inter (default genérico). Plex = voz
  institucional/engenheirada, casa com "ferramenta de gestão".
- **Legibilidade mobile:** contraste por peso/caixa/tracking/entrelinha; corpo com
  piso de 16px; título limitado por `clamp` para não engolir a tela.
- **`!important` proibido:** reset de motion movido para a camada `utilities`
  (última, vence por ordem de camada).
- **Fontes via Google Fonts CDN** por ora (preconnect + swap, só pesos usados).
  Self-host com `size-adjust` fica para o passe de performance (reduz CLS e
  remove conexão de terceiros).
- **Medição:** `tracking.js` dispara `whatsapp_click` no `dataLayer` + `generate_lead`
  se `gtag` existir. Delegação de evento cobre CTAs futuros. GA4/Ads entram depois.

## Etapa 1 — Shell global (2026-09-20)

**O que:** `index.html` com `lang="pt-BR"`, meta/OG, `theme-color`, preconnect e
fontes, skip-link, cabeçalho fixo com wordmark, `<main>` e os três CSS em ordem
fixa. Seções 2–15 como marcadores comentados na ordem canônica.

**Por quê:**
- Cabeçalho só com wordmark por ora; CTA fixo entra na etapa de conversão, com
  rótulo de copy aprovada — evita inventar texto cedo.
- Seções não construídas ficam como comentários, não como stubs vazios: página
  não parece amadora/quebrada no preview e cada etapa converte um comentário em
  seção real.

## Etapa 2 — Hero (2026-09-20)

**O que:** Seção 1 completa com a copy aprovada, foto 4:5 em placeholder, CTA para
WhatsApp e barra de credenciais.

**Por quê / decisões de execução:**
- **Layout:** mobile em coluna única com a base da foto derretendo no fundo (scrim
  funcional); desktop em duas colunas (texto à esquerda, retrato à direita).
  Alinhamento à esquerda, não centralizado — centralizar bloco longo é tell de
  template.
- **Linha de contexto** "Para empresas e para líderes" em caixa de frase,
  `--text-400` — evita o vício do rótulo caixa-alta tracked-out acima do heading.
- **Credenciais** separadas por fio (`border-inline-start`), não por ponto médio
  — resolve o vício de "metadados unidos por ponto médio" mantendo o conteúdo da
  copy aprovada.
- **Placeholder do hero:** `<img>` 1200x1500 com `aspect-ratio` 4:5, `fetchpriority="high"`,
  `data-final-src`/`data-min-size`. Não lazy. Preload entra com o arquivo real.

**Pendências registradas (recomendações de copy aguardando aprovação do cliente):**
- Apoio do hero contém "resultados extraordinários" — sinalizado como o trecho mais
  próximo do guru-motivacional (item D da crítica). Mantido como está até decisão.
- Ver também itens A–K da crítica no arquivo de plano.

## Etapa 3 — Seção 2 Cenários (2026-09-20)

**O que:** 10 cenários de dor, fechamento e CTA. Componente `.section-head`
reutilizável criado em `components.css`.

**Por quê / decisões de execução:**
- **Fundo elevado (`--ink-800`)** para separar do hero. Estabelece o ritmo de
  alternância das seções (2 elevada, 3 fundo-base, 4 elevada...).
- **Sem numeração 01/02/03** (vício e nota da copy): os dez itens são cenários
  paralelos, não sequência. Marcador é um traço curto de acento por item —
  distinto do tique vertical das credenciais, para cada seção ter identidade.
- **Duas colunas no desktop** (≥48rem) para os dez itens não virarem uma coluna
  cansativa; coluna única no mobile.

## Etapa 4 — Seção 3 Prejuízo (2026-09-20)

**O que:** Dois blocos de estatística (custo do burnout, ralo da comunicação) e
a citação-destaque. Este é o elemento memorável da página.

**Por quê / decisões de execução:**
- **Aposta ousada = número gigante.** `.stat__figure` tem teto de 7rem, acima do
  hero (4.5rem), de propósito. A alavanca mais forte sobre um C-level é a aversão
  à perda; dar ao custo da inação a maior voz tipográfica da página é estratégia,
  não decoração. Resto da página fica sóbrio para isto pousar.
- **Sem grade de cards com sombra** (vício): cada estatística é afirmação
  tipográfica (número + legenda), separada por fio; ritmo editorial figura +
  legenda no desktop (número à esquerda, explicação à direita).
- **Unidade em `--accent-400`** abaixo do número — usa o acento como marcador de
  dado, não como decoração.
- **Separador "—" da copy** expresso via layout (número/explicação em elementos
  distintos). Mesma abordagem nas seções 4, 6 e 7: as palavras não mudam, o traço
  vira estrutura. Se o cliente quiser o traço literal, é trivial.
- **Fundo base (`--ink-900`)** — os números pop no fundo mais escuro.
- **Nota de credibilidade (pendência):** "44%" e "7,5 horas" seguem sem fonte na
  copy (item F da crítica). Público analítico descarta número sem fonte. Aguarda
  decisão do cliente.

## Etapa 5 — Seção 4 Diferença (2026-09-20)

**O que:** Comparação mito × realidade em duas colunas e a citação-destaque.
É o eixo do posicionamento ("não é terapia, é ferramenta de gestão").

**Por quê / decisões de execução:**
- **Fujo do "dois cards antes/depois".** O dispositivo é ótico: a coluna do mito
  recua (fundo `--ink-900` mais escuro que a seção, texto todo em `--text-400`);
  a da realidade avança (fundo com 9% de acento, termos em `--accent-400`, texto
  pleno `--text-100`). O recuo→avanço carrega o "versus", sem seta literal (vício).
- **`<dl>` com pares termo/descrição** — semântica de "termo: definição" ajuda o
  leitor e o leitor de tela.
- **Colunas empilham no mobile** (mito, depois realidade); lado a lado no desktop.
  Alinhamento de linhas é aproximado (conteúdo de tamanhos diferentes) — o
  contraste dim×pleno carrega o sentido mais que o pixel-perfect.

## Etapa 6 — Seção 5 Método (2026-09-20)

**O que:** Seção editorial de prosa (o que é a Gestalt corporativa), três
parágrafos com parágrafo-lede maior.

**Por quê / decisões de execução:**
- **Sobriedade.** Depois do impacto dos números (3) e do contraste (4), a seção
  respira: prosa na medida de leitura (66ch), sem ornamento. Só o primeiro
  parágrafo é maior (lede) para dar hierarquia editorial.
- **Fundo base** — mantém a alternância (4 elevada, 5 base).
- Aspas tipográficas em "forma"/"todo" (upgrade de apresentação, palavras
  intactas).

## Etapa 7 — Seção 6 Entregável (2026-09-20)

**O que:** Cinco aprendizados da imersão (termo + descrição) e CTA.

**Por quê / decisões de execução:**
- **Sem cards com sombra idêntica** (vício): lista com fios entre itens, ritmo
  termo (esquerda) / descrição (direita) no desktop — reaproveita o sistema da
  seção 3, mas com termos textuais em vez de números; coeso, não repetitivo.
- **Fundo elevado** (5 base, 6 elevada).
- CTA `data-cta-section="entregavel"`. Rótulo "destravar a performance da minha
  equipe" é copy aprovada; observação da crítica (item A: a página oscila entre
  líder e equipe) segue registrada, sem alterar copy.

## Etapa 8 — Seção 7 Metodologia (2026-09-20)

**O que:** A seção mais densa. Duas tríades da copy resolvidas em dois blocos
visuais distintos, mais a citação e o CTA.

**Por quê / decisões de execução:**
- **Problema estrutural da copy (item E da crítica):** a seção contém dois "três
  pilares" diferentes. Em vez de um muro de seis pilares, separei em dois blocos
  com tratamentos distintos: Bloco 1 (relação — Sigilo/Acolhimento/Foco) como
  cards com fio de acento no topo, cada um com afirmação em destaque, texto e
  nota; Bloco 2 (resultado — Consciência/Responsabilidade/Contato) como lista
  compacta com termo em acento. Formatos diferentes tornam legível o que a copy
  empilhou.
- **Rótulos de campo da copy tratados como formatação, não texto:** "Nota:" (como
  antes "Destaque:", "Título:", "Botão:") é marcador do documento de copy, não
  texto de página. Renderizo só o conteúdo. Mesma regra dos separadores "—".
- **Hierarquia de heading:** h2 (seção) → h3 nos três pilares do Bloco 1 e no
  título do Bloco 2. Itens do Bloco 2 são termos em negrito, não headings, para o
  outline não confundir grupo com item.
- **Fundo base** (6 elevada, 7 base).

## Etapa 9 — Seções 8, 13, 14, 15 (2026-09-20)

**O que:** Fechamento do fim da página a pedido do cliente: depoimentos (8),
conversão (13), FAQ (14) e contato/rodapé (15). Seções 9–12 (sobre, publicações,
parceiros, linkedin) ficaram fora deste lote, por escopo definido pelo cliente e
por dependerem de decisões de copy em aberto (itens A, C, G da crítica).

**Por quê / decisões de execução:**
- **Depoimentos (8, elevada):** três citações separadas por fio, sem card com
  sombra (vício). Autoria com iniciais em `--text-100` e data em `--text-400`,
  vírgula da copy preservada (sem ponto médio). No desktop, três colunas alinhadas
  ao topo. Rodapé "verificados no Doctoralia" em nota discreta — mantido como copy
  aprovada; a ressalva de posicionamento (item C) segue registrada, sem alterar.
- **Conversão (13, base):** banda de destaque com tinta de acento (`color-mix`
  10% sobre `--ink-800`), não gradiente decorativo. É a única seção com painel
  contido — o acento da marca dá ênfase à conversão sem sombra cinza. Título em
  display, raio 8px (acima do botão, 4px) marcando hierarquia.
- **FAQ (14, elevada):** `<details name="faq">` nativo — accordion **exclusivo**
  (abrir um fecha o outro) sem JavaScript, acessível por teclado, funciona com JS
  desativado. Descartei `main.js`: o recurso nativo é mais robusto e mais leve.
  Indicador "+" que vira "−" desenhado em CSS (não é seta anexada a texto).
  Perguntas renderizadas sem os números "1./2." do documento (mesma regra dos
  cenários: numeração de documento não é conteúdo de página).
- **Contato/rodapé (15, base):** última chamada dentro do `<main>`; `<footer>`
  como landmark próprio fora do `<main>`. Contato com e-mail (`mailto`) e WhatsApp
  (medido como `cta_section="rodape"`); redes e agendamento como texto (sem URLs
  fornecidas, não inventar link). **Aviso CVV/SAMU legível** no rodapé, com fio de
  separação — profissionalismo responsável sem competir com a conversão (item H).
- **Alternância de fundo mantida** para as seções existentes: 7 base → 8 elevada →
  13 base → 14 elevada → 15 base.
- **Tracking:** os quatro novos CTAs (conversao, contato, rodape) entram pela
  delegação já existente em `tracking.js` — nada mudou lá.
- **Validação:** sem overflow horizontal em 390 e 1440 (`scrollWidth == innerWidth`,
  zero offenders); accordion exclusivo confirmado por teste (abrir dois deixa um só).

**Pendência de estrutura (não é copy de marketing, aguarda seu aval):**
- O FAQ não tem título na copy aprovada. Precisei de um rótulo acessível para o
  landmark e usei o h2 **"Perguntas frequentes"** — termo neutro e universal. Se
  preferir outro, ou nenhum título visível, ajusto.

---

## Etapa 10 — Reformulação visual premium (redesign global)

Redesign de apresentação a pedido do cliente (skill `frontend-design` +
`impeccable` + `design-taste-frontend`), com três referências visuais em
`assets/images/ref/`. **Regra absoluta respeitada: nenhuma palavra da copy mudou.**
Só mudaram distribuição, hierarquia, composição, atmosfera e movimento. Estrutura,
conteúdo e todos os CTAs/mensagens de WhatsApp preservados.

**Direção definida (leitura das referências):** consultoria boutique / executivo
premium. Extraí das refs os princípios (não copiei nenhuma): fotografia que
participa da composição e derrete no fundo; composição editorial variada por seção;
ritmo impacto × respiro; tipografia com protagonismo; números como autoridade;
profundidade/atmosfera; menos "cards"; transições contínuas entre seções.

**Paleta — conflito resolvido.** O brief pediu "paleta mais rica, não só azul
escuro + branco + azul elétrico". O mandato de marca (CLAUDE.md) proíbe tom quente
(sem dourado/laranja). Enriqueci **friamente**: faixa tonal profunda nos escuros
(ink-950→750, atmosfera em gradientes radiais, não retângulos) + um **metal frio
(platina/aço)** para rótulos, fios e detalhes (ecoa o relógio de aço do retrato e a
ref 02). O único calor da página é **dentro da foto do pôr do sol** (método) —
diegético, não cor de marca. Nada de ouro.

**Fotografia (3 imagens reais):**
- hero → retrato de estúdio sangra à direita e **derrete no fundo** por máscara de
  gradiente (fundo quase preto da foto funde com a página; sem PNG recortado).
- gestalt-metodo → **seção método em tela cheia**, foto cinematográfica com scrim
  direcional; o calor do entardecer vira atmosfera, texto legível à esquerda/base.
- sobre → retrato em coluna sticky com **duotone frio** (grayscale + overlay de
  aço) para unir o cinza neutro à paleta.

**Composição por seção (famílias distintas, evita "blocos empilhados"):** hero
split assimétrico · cenários dois painéis (título sticky | linhas) · prejuízo
números gigantes (autoridade) · diferença oposição mito recua/Gestalt avança com
eixo central · método full-bleed · entregável índice editorial · metodologia
pilares em ritmo vertical + tríade payoff · depoimentos 1 em destaque + 2 apoio ·
sobre retrato + trajetória · conversão declaração centrada com luz · FAQ duas
colunas · contato + rodapé. Fundos alternam por **lavagens que desbotam nas bordas**
(`.section--raised`, `.section--band`), não caixas de cor sólida.

**Movimento (sóbrio, motivado):** um momento autoral — o hero entra em sequência
escalonada ao carregar (CSS puro). O resto revela na rolagem via
IntersectionObserver (`assets/js/main.js`), modos `up`/`stagger`. Sem JS, tudo
visível; `prefers-reduced-motion` colapsa para estático. Hover tátil nos botões.

**Cabeçalho:** wordmark refinado + **CTA sempre visível** ("Agendar diagnóstico",
`cta_section="cabecalho"`) — caminho de conversão permanente numa LP longa mobile.
Some em telas < 33rem (os CTAs de seção conduzem).

**Craft / anti-slop (skill impeccable):** rodei o detector mecânico; **0 findings**
ao final. Correções aplicadas no caminho: removido texto com gradiente nos números;
sombra dos botões trocada de "glow azul" (tell de IA) por elevação neutra; barra
lateral colorida das citações substituída por citação editorial ampla; eyebrow do
hero (rótulo com traço) removido; caixa-alta longa em `<p>`/citações revertida para
caixa de frase (legibilidade); contraste do texto faint elevado para passar AA;
`overflow` do body dispensado (cada seção que sangra se recorta). Geometria validada
sem overflow horizontal em 390 e 1440 (0 offenders).

**Fontes:** mantidas Saira Condensed (display, caixa alta em títulos) + IBM Plex
Sans (corpo) — par já decidido, alinhado à marca; troca agora contradiria decisões
e não agregaria. O ganho veio de composição, escala, atmosfera e movimento.

**Não incluído (aguarda seu aval, itens em aberto de antes):** seções 10–12; ajustes
de copy do FAQ (vocabulário clínico) e preço; título "Perguntas frequentes".

## Etapa 11 — Reconstrução visual do frontend do zero (2026-09-20)

**Contexto:** a direção visual anterior (Etapa 10) foi descartada por decisão do
cliente — a página estava pesada, textual e a fotografia "sumia" atrás de máscaras
e duotone. Reconstrução da linguagem visual do zero a partir de um briefing
específico. **A copy aprovada não mudou uma palavra. A camada funcional foi
integralmente preservada:** todos os `href` de WhatsApp com texto pré-preenchido
por seção, `data-cta`/`data-cta-section`, `tracking.js` (intocado), `main.js`
(reaproveitado), IDs, âncoras, FAQ nativo (`details name="faq"`), rodapé e aviso do
CVV. `base.css`, `components.css`, `sections.css` e `index.html` reescritos.

**Diagnóstico do problema real:** as fotos sempre existiram e são excelentes. A
execução anterior as enterrava em overlay. Correção de raiz: deixar a fotografia
respirar.

**Direção (briefing):** escuro, executivo, boutique premium. Referências `ref/01`
(ícones lineares para quebrar parede de texto; marca conceitual para abstrato;
profundidade por luz) e `ref/02` (hierarquia tipográfica, números gigantes como
autoridade, luz azul sutil, cards só onde ajudam).

**Decisões-chave:**
- **Calor pontual × marca:** a marca proíbe cor quente na UI. O único calor da
  página é diegético, dentro da foto do pôr do sol (seção método). Sistema de cor
  segue frio, azul elétrico como acento único. Confirmado no briefing.
- **Ícones:** família SVG linear coerente (sprite `<symbol>`/`<use>`, traço 1.5,
  `currentColor`), sem build. Aplicada em cenários, prejuízo, diferença,
  entregável, metodologia e credenciais do sobre. Reduz a "parede de texto" sem
  tocar no texto.
- **Marca conceitual da Gestalt:** três círculos sobrepostos (o todo > partes),
  usada uma vez, na seção método.
- **Travessão da copy vira estrutura:** nas credenciais do sobre, o "—" entre termo
  e descrição foi expresso por hierarquia (termo em peso forte + descrição), sem
  imprimir o caractere. Nenhuma palavra removida. (Consistente com decisão da
  Etapa 4.)
- **Famílias de composição distintas por seção** (hero split · cenários grade de
  ícones · prejuízo números gigantes · diferença oposição · método full-bleed ·
  entregável índice sticky · metodologia tríptico + payoff · depoimentos destaque+2
  · sobre split · conversão banda centrada · FAQ accordion · contato). Ritmo
  alterna densidade.

**Segurança de layout (exigência do briefing):** grid/flexbox/fluxo, texto nunca em
`position:absolute` (só a foto do método é camada decorativa atrás de scrim, com o
texto em fluxo normal e fundo garantido). **Overflow horizontal medido em 0** a 390
e 1440. Bug corrigido no caminho: sangria do hero por `calc(50% - 50vw)` estourava
324px; trocada por grid full-width com texto alinhado por padding ao `.shell`.
Scrim do método calibrado (forte só no terço esquerdo no desktop; véu uniforme no
mobile, onde o texto ocupa a largura toda) para o pôr do sol aparecer sem prejudicar
a legibilidade.

**Validado em navegador** (desktop 1440 e mobile 390), seção por seção.

**Segue não incluído:** seções 10–12 (dependem de assets inexistentes — logos de
parceiros, imagens de publicações, posts reais; criá-las agora seria conteúdo
inventado). Ajustes de copy em aberto (fonte de estatísticas, preço, "resultados
extraordinários") seguem como decisão do cliente, sem bloquear.

---

## Etapa 12 — Correção de bugs + refino premium (2026-09-21)

**Contexto:** avaliação apontou conteúdo invisível (seções 2, 3 e depoimentos) e
"animações com comportamento incorreto". Prioridade: corrigir a causa real primeiro,
depois refinar. A copy e a camada funcional permaneceram intactas.

**Causa-raiz dos bugs (uma só):** a regra de reveal `.js [data-reveal] { opacity:0 }`
atingia também os *containers* `data-reveal="stagger"`. O `showGroup()` só marcava
`is-visible` nos *filhos* — o container nunca era revelado e ficava preso em
`opacity:0`, escondendo todo o conteúdo (cenários, blocos de estatística,
depoimentos, entregável, pilares). As "animações erradas" eram os filhos animando
sob um pai invisível. Diagnóstico confirmado no DOM ao vivo (container opacity 0,
filhos opacity 1).

**Correções:**
- **Reveal (components.css):** só `[data-reveal="up"]` e os *filhos diretos* de
  `[data-reveal="stagger"]` partem ocultos. O container stagger nunca recebe
  `opacity:0`. Conteúdo não pode mais ficar preso invisível.
- **Rede de segurança (main.js):** `try/catch` + fallback sem IntersectionObserver +
  timeout que revela tudo que sobrar. Garantia de que nenhuma seção fique oculta,
  mesmo se o observer falhar.
- **Cache-busting:** `?v=N` nos CSS/JS — força o navegador a buscar a versão nova a
  cada deploy na Locaweb (evita ver CSS antigo em cache).

**Refino premium:**
- **Método (a quebra visual da página):** a foto do pôr do sol estava afogada,
  sobretudo no mobile. Novo tratamento — mobile: foto vira **banda cinematográfica
  no topo** (pôr do sol visível), texto abaixo em fundo sólido (legibilidade
  garantida); desktop: foto em tela cheia atrás do texto à esquerda, pôr do sol
  lendo à direita. `z-index` positivo (nunca negativo) para a imagem ficar acima do
  fundo da seção e sob o texto. O único calor diegético da página agora tem presença
  real.
- **Botão primário (.btn--solid):** contraste do texto branco subiu de 2.5:1 para
  ≥4.5:1 (AA) com azul mais profundo; **glow azul removido** (a "estética gamer" que
  o briefing proíbe) e trocado por elevação neutra com fio de luz superior. Afeta os
  7 CTAs.

**Validação:** detector mecânico de design 29 → 15 achados (os 15 restantes são a
identidade da marca — display condensado em caixa alta, entrelinha de display — ou
falsos positivos: conteúdo recuado via `.shell`, `overflow-x:hidden` de segurança com
overflow medido em 0). Sem erros de console. Tracking de WhatsApp confirmado ao vivo
(`whatsapp_click` no dataLayer, hrefs intactos). Desktop e mobile revisados seção a
seção; overflow horizontal 0 a 375.

---

## Etapa 13 — Refino premium: tipografia serifada + cor respirando (2026-09-21)

**Contexto:** avaliação do cliente (via /design-taste-frontend) — identidade ok, mas
o site com "cara de IA", muito plano, e sem luxo. Pediu tipografia mais luxuosa
(serifada), cor "respirando" em vez de monótona, e cards/ícones/animações mais
premium (não cara de PDF/PowerPoint). Referências: siimonesouza.com.br (serifada
Cinzel + harmonia) e lp.vende-c.com (escuro premium + pops de cor). Decisão do
cliente: **serifada nos títulos** e, no hero, **manter título + parágrafo** (remover
a linha azul "Mentoria estratégica..." e as credenciais). Identidade (azul elétrico,
fundo escuro) e estrutura preservadas.

**Sistema tipográfico (a virada de luxo):**
- **Cinzel** (serifada gravada, caixa alta) nos títulos display — hero, títulos de
  seção, termos de pilar, fechamentos. Autoridade clássica, "gravada em pedra".
- **Cormorant Garamond** (serifada editorial de alto contraste) em citações
  (itálico), depoimentos (itálico) e nos números gigantes. É a voz "humana/editorial"
  que quebra a monotonia e eleva o luxo.
- **IBM Plex Sans** segue no corpo, rótulos e UI (legibilidade).
- Escala e entrelinha recalibradas (Cinzel é mais larga/alta que a condensada).

**Cor respirando:** atmosfera de base enriquecida; luz azul sutil atrás dos números
gigantes (`background-image` na seção, sempre sob o conteúdo — sem risco de z-index);
acentos elétricos deliberados (unidades, iniciais, filetes) como "suspiros", nunca a
palavra-colorida-única do título (vício de IA vetado no CLAUDE.md). Sem glow gamer.

**Componentes mais verdadeiros:**
- Depoimentos: cards com gradiente sutil, borda refinada, cantos 12px e aspas
  gravadas (Cormorant, acento, baixa opacidade); citações em serifada itálica —
  editoriais, humanas, não "bullet de slide".
- Números gigantes em Cormorant (contraste dramático, numeral de luxo).
- Motion: reveal com leve desfoque (blur-in) além de opacidade/deslocamento — entrada
  mais sofisticada. Rede de segurança de reveal mantida (nada some).

**Hero:** removidos a linha azul "Mentoria estratégica..." e o bloco de credenciais
(seguem na seção Sobre). Título serifado + parágrafo descritivo como subheadline + CTA.

**Validação:** overflow horizontal 0 em 375 e 1440; 6 estilos de fonte carregados
(Cinzel 500/600, Cormorant 500 itálico/600, Plex 400/600); detector 13 achados, todos
identidade de marca ou falsos positivos; sem erros de console; CTAs/WhatsApp/tracking
intactos. Revisado seção a seção em desktop e mobile.

---

## Etapa 14 — Refino de layout: ritmo, hierarquia de imagem, dinamismo (2026-09-21)

**Contexto:** pedido do cliente (via /ui-ux-pro-max) — layout ainda mais moderno,
premium e dinâmico, "acima da média", como as referências: distribuição de elementos,
hierarquia das imagens e copy fácil de ler. Sem mudar identidade nem estrutura.
Guiado por buscas verificadas da skill (readability 65-75ch + entrelinha 1.5-1.75;
parallax só em camadas de imagem, delta pequeno, respeitando reduced-motion; padrão
de storytelling com hierarquia clara por seção).

**Legibilidade (copy mais fácil de ler):**
- Medida de leitura 62ch → **66ch**; entrelinha de prose **1.72**; espaçamento entre
  parágrafos (`.flow`) 1rem → 1.3rem.
- Ritmo vertical mais generoso: `--section-y` até 10rem (respiro premium).

**Hierarquia de imagem:**
- Retrato do Sobre agora em **recorte editorial 4:5** (rosto ao torso, cover), com
  moldura refinada e base que funde no escuro — mais protagonismo e consistência com
  a spec de imagem do projeto. Antes era a figura inteira em altura natural.

**Dinamismo (moderno, sem prejudicar leitura):**
- **Parallax sutil** só na fotografia do método (camada decorativa): zoom base 1.14 +
  deslocamento contido ±4,5% no scroll, contido por `overflow:hidden` (sem brechas nas
  bordas, sem overflow de página). Vanilla JS, rAF, `will-change` gerenciado, e
  **desligado em prefers-reduced-motion**. Texto nunca recebe parallax.

**Validação:** overflow horizontal 0 em 375 e 1440 (a imagem do método escalada é
maior que o container mas fica recortada — não gera scroll); parallax confirmado ao
vivo (scale+translate no inline style); sem erros de console; detector 13 achados
(mesmo conjunto de identidade/falsos positivos). Revisado desktop (via DOM, pois o
painel recorta emulações > largura física) e mobile seção a seção.

## Etapa 15 — Spotlight nos pilares + hierarquia dos títulos (2026-09-21)

**Contexto:** pedido do cliente (via /impeccable) — (1) instalar dinamismo de card
premium nos pilares da metodologia (referência: componente "SpotlightCards" com tilt
3D, luz seguindo o cursor e recuo dos irmãos); (2) pente-fino de hierarquia — títulos
"muito à esquerda / muito curtos", deixá-los melhor posicionados e mais premium; (3)
menos cara de IA, mais parecido com as referências no layout (harmonia texto+visual).
Portado o efeito para HTML/CSS/JS puro e reafinado à identidade fria (azul único, sem
cor quente, sem glow gamer). Payoff mantido como lista, não um segundo grid de cards
(evita o "duas fileiras de cards idênticos", vício de IA).

**Sistema de cabeçalho de seção (a correção de hierarquia):**
- Novo modificador `.section-head--center`: abertura centrada com filete de acento
  centrado (fade simétrico) e apoios centrados. Aplicado às 5 seções que abrem com
  cabeçalho autônomo — cenários, prejuízo, diferença, metodologia, depoimentos.
- As seções em composição assimétrica (hero, sobre, método, entregável, FAQ) seguem
  alinhadas à esquerda. Resultado: **intro centrada + conteúdo estruturado** (o ritmo
  das referências), com alternância real — não centralização de tudo.

**Pilares viram cards com spotlight (só na seção metodologia):**
- Superfície igual à dos depoimentos (gradiente + fio + raio 12px), badge de ícone
  azul discreto (tint 0.10 + anel interno), fio de acento na base crescendo no hover
  via `transform: scaleX` (GPU, sem reflow).
- **Inclinação magnética** ≤5° e **luz radial azul seguindo o cursor** (`--mx/--my/
  --glow` por JS, rAF-throttled). Em repouso a luz é invisível (`--glow: 0`).
- **Recuo do irmão fora de foco** (opacity 0.62) em CSS puro via `.pillars:hover
  .pillar:not(:hover)`.
- Só em `(hover: hover) and (pointer: fine)`; desligado em toque e em
  prefers-reduced-motion (o JS nem registra listeners). Sem `!important`.
- Convivência com o reveal: o transform inline só é setado no pointermove (bem depois
  do reveal), e é limpo no pointerleave — o reveal de entrada continua intacto.

**Validação:** desktop 1280 — 0 overflow horizontal; 3 cards iguais (344px, altura
464px); cabeçalhos centrados com folga esquerda = direita (balanceados). Mobile 375 —
0 overflow, nenhum elemento mais largo que a viewport, cards empilhados, títulos
centrados legíveis (inclusive o mais longo, diferença). Tilt/glow confirmado ao vivo
(rotateX/Y + --glow setados no pointermove, limpos no leave); sem erros de console.
Detector: 18 → 16 após corrigir `transition: width` (→ scaleX) e a linha longa do
aviso do rodapé (90ch → 70ch). Os 16 restantes são todos ganhos-de-marca ou falsos
positivos verificados: títulos display em caixa alta (identidade), spotlight dos
pilares (efeito pedido, apagado em repouso) + atmosfera do prejuízo (spec de luz da
marca), entrelinha 1.22 das pull-quotes (escala display), e 8 de baixo contraste que
na medição real dão 7,85–18:1 sobre o fundo (o detector superestima o gradiente).

## Etapa 16 — Ícones em selo, comparativo em cards e flip cards (2026-09-21)

**Contexto:** pedido do cliente (via /impeccable), aprovando o estado atual e pedindo
realces pontuais, com referência a dois componentes KokonutUI (SpotlightCards já
portado; agora o CardFlip) e à LP Xeque-Mate (ícones em selo). Regras de marca
mantidas: o CardFlip original é todo laranja (#ffa500) → convertido para o azul da
marca; nada de emoji (a família é o sprite SVG linear).

**Ícones mais evidentes (selo azul, anel interno discreto):**
- Cenários (sobretudo no mobile), Entregável (frente dos cards) e Sobre
  (trajetória/autoridade) agora usam ícone em selo arredondado, azul da marca.
- Sobre ganhou também micro-interação no hover (selo acende, leve translate) e
  entrada em stagger — o pedido de "mais dinâmico".

**Diferença — comparativo em cards discretos com tilt/luz:**
- As duas colunas (mito × realidade) viraram cards (superfície quase plana, fio 1px,
  raio 12px) com a mesma luz/inclinação dos pilares (reutilizando `[data-tilt]` +
  `.tilt-glow`). Distinção mito × realidade sem o marcador de 2px (que o detector
  sinaliza em card arredondado): realidade = superfície levemente mais azul + borda
  `hairline-accent` + ícones de acento; mito = neutro/aço. Reveal em stagger.

**Entregável — flip cards (o efeito pedido):**
- Os 5 aprendizados viraram flip cards. Frente: ícone em selo + o benefício (título)
  + dica "ver mais". Verso: a elaboração (a copy aprovada, intacta). O benefício fica
  visível sem virar — só o detalhe vai para o verso (importa numa página de conversão
  para quem escaneia).
- Vira no hover e no foco de teclado onde há hover real (`@media (hover: hover)` +
  `:focus-within`); no toque, tap alterna `.is-flipped` (JS detecta ponteiro grosso);
  Enter/Espaço no teclado. Respeita prefers-reduced-motion (sem transição).
- **Altura sem corte, sem altura fixa:** as duas faces empilham na mesma célula de
  grade (`grid-template-areas: "stack"` + `backface-visibility`), então o card mede
  pela face mais alta; no desktop, `grid-auto-rows: 1fr` iguala as alturas por linha.
  Verificado: 0 corte na frente e no verso em 375 e 1280.
- Cabeçalho do Entregável passou a centrado (consistente com o sistema da Etapa 15).

**Validação:** desktop 1280 — 0 overflow; flip cards 3+2 iguais (238px), verso não
espelhado e legível (inclusive o mais longo); cards de diferença iguais (484px).
Mobile 375 — 0 overflow, coarse detectado, tap alterna o flip (recarregado no modo
mobile para o JS inicializar como toque), cards em altura natural sem corte. Sem erros
de console. Detector 22 → 18 após corrigir 2 achados reais (marcador de 2px em card
arredondado → borda 1px; rótulo do verso em caixa alta 40+ chars → caixa normal). Os
18 restantes seguem ganho-de-marca/falso positivo (mesma leitura da Etapa 15, agora
com 6 spotlights: prejuízo + 3 pilares + 2 diferença — todos apagados em repouso).

## Etapa 17 — Alinhamento de CTAs, botões refinados e mobile (2026-09-21)

**Contexto:** pedido do cliente (via /impeccable). Remoções, alinhamento consistente
das CTAs, refino visual dos botões e correção de animações no mobile.

**Remoções (redundância):**
- Cenários: removido o fecho "Invista na sua estrutura psicológica." — fica só a CTA.
- Metodologia: removido o intro do payoff ("Como a Gestalt aplicada resolve...").

**Alinhamento das CTAs = alinhamento do título da seção:**
- Regra: seção com cabeçalho centrado → CTA centrada; seção em split → CTA à esquerda.
- Centradas: Cenários, Entregável, Metodologia (via `.cta--center`) + título do payoff.
  Continuam à esquerda: hero, sobre, contato (splits). Conversão já era centrada.
- Verificado no DOM: folga esquerda = direita nas três CTAs centradas; hero permanece
  à esquerda (48px vs 333px).

**Botões mais apurados:**
- `.btn--solid` ganhou anel de acento interno (`inset 0 0 0 1px`) para definição,
  brilho sutil no hover (`brightness(1.06)`) e sombra em camadas mais profunda —
  mantendo o gradiente azul que passa AA (sem glow externo/gamer). Padding um pouco
  maior, letter-spacing leve.
- **Mobile:** CTA principal em largura total (`max-width: 32rem`) — alvo de toque
  confiável e visualmente mais forte. Confirmado 335px = largura do conteúdo.

**Mobile — animação que "não funcionava":**
- **Parallax desligado no toque** (`(hover: none), (pointer: coarse)`): scroll-parallax
  trepida e custa performance no celular; a foto do método agora fica estática (banda
  limpa, sem jank). No desktop segue ativo. As demais animações do mobile — reveal em
  scroll, flip cards no tap, `:active` dos botões — verificadas funcionando; os efeitos
  de hover (tilt/luz/dim) são de mouse e permanecem exclusivos do desktop por decisão.

**Validação:** desktop 1280 — 0 overflow; 3 CTAs centradas balanceadas; hero à
esquerda; título do payoff centrado; textos removidos ausentes. Mobile 375 — 0
overflow; CTAs em largura total; método sem parallax (0 transform inline); reveals e
flip ok. Sem erros de console. Detector 18 → 17 (o fecho removido zerou 1 all-caps);
os 17 são o mesmo conjunto de ganho-de-marca/falso positivo.

## Etapa 18 — Correção do flip no celular (bug crítico) (2026-09-21)

**Contexto:** cliente reportou que no celular o flip card não virava no toque — só
no desktop (hover). Bug bloqueante para ir ao ar (afeta o funil).

**Causa raiz:** a técnica anterior usava `transform-style: preserve-3d` no
`.flip__inner` que é `display: grid`. Esse combo **falha no Safari do iPhone** (achata
o 3D): a classe `.is-flipped` até entrava, mas o giro não renderizava. No desktop
(Chrome) funcionava, mascarando o problema.

**Correção (sem preserve-3d, compatível com todo navegador):**
- Removido `preserve-3d`. Agora **cada face gira sozinha**: a frente vai de
  `rotateY(0)`→`180deg` (some pelo `backface-visibility`) e o verso vai de
  `180deg`→`360deg` (aparece). A perspectiva fica no `.flip__inner`. O empilhamento em
  grade (altura automática, sem corte) foi mantido.
- **JS mais robusto:** o tap passa a ser anexado sempre que **não** for hover fino
  (`!(hover: hover) and (pointer: fine)`) — cobre celular, tablet e híbridos, em vez de
  depender de `(pointer: coarse)`, que alguns aparelhos reportam errado. `cursor:
  pointer` no card garante o disparo do click no iOS. Enter/Espaço no teclado seguem.

**Validação:** mobile 375 (recarregado no modo toque) — tap vira o card, o **verso é
legível e não espelhado**, segundo tap volta; 0 corte, 0 overflow, sem erros de
console. Desktop 1280 — mesmas matrizes de giro renderizam (frente `rotateY(180)`,
verso `rotateY(360)`); hover segue exclusivo do desktop, sem click handler. Detector
17 (inalterado — correção de mecânica, sem novo padrão).

---

## Etapa 19 — Prejuízo: de lista estática a bento de dados (2026-09-21)

**Pedido:** deixar a seção "O prejuízo silencioso" mais dinâmica e com mais leveza,
usando gráficos; o cliente liberou dourado e um card branco.

**Decisão estratégica (perguntada e confirmada):** o dourado colide com a regra de
marca do projeto (azul-elétrico como único acento, nenhum tom quente) e é justamente
a combinação que mais escorrega para cara de template/IA num fundo azul escuro. Levei
os dois caminhos ao cliente com recomendação — ele escolheu **azul + card claro**. A
leveza vem de layout + porcelana, não de cor quente.

**O que mudou (só apresentação; copy aprovada preservada 100%):**
- Estrutura antiga (`.stat`/`.stat__figure` em lista vertical) trocada por um **bento
  de perda** (`.loss-bento` / `.loss-cell`). Célula com peso próprio, não cards gêmeos.
- **Painel claro âncora** (`--paper*`, porcelana fria com cast azulado — não creme
  quente) para "R$ 180 bilhões por ano", texto em azul-tinta profundo (`--paper-ink`,
  ~15:1). É a quebra de leitura que dá a leveza pedida. Elevação por sombra + realce
  interno (sem borda sob sombra / ghost card). Raio 16px (hierarquia acima das células).
- **Micrográficos que codificam o número aprovado** (não são sparklines decorativas):
  donut 44% (bloco B), barra 20% da produtividade (bloco B), três segmentos = 3 meses
  (bloco A). Todos animam a entrada no scroll via `.is-visible`, com **estado final como
  padrão** (sem JS e com `prefers-reduced-motion` já aparecem preenchidos). Sem JS novo
  — reaproveita o sistema de reveal existente. Fill por `scaleX`/`stroke-dashoffset`
  (nunca `width`, para não disparar layout-transition nem jank).
- Flag regulatório **NR-1 e PGR** com ícone de escudo (`#i-shield`).
- Rótulos de bloco viraram **divisor editorial** (ícone + texto sentence-case + fio que
  se estende), removendo o caixa-alta+letter-spacing (vício de IA / kicker).

**Tokens novos (base.css):** `--paper #e8ecf3`, `--paper-hi #f5f7fa`, `--paper-ink
#0b1626`, `--paper-ink-soft #43536e` — única superfície clara da página, reservada a
este bloco de dados.

**Validação:** desktop 1280 e mobile 390 — bento correto (bloco A: painel alto +
meses + flag; bloco B: dois gráficos), leitura fluida, gráficos renderizam, 0 overflow
horizontal (390=390), citação editorial fecha a seção. Detector caiu de 17 → 13: os
restantes são atmosfera dos pilares (radial-glow), pull-quotes serifadas
(tight-leading 1.22) e 4 low-contrast que são leitura errada do gradiente (contraste
real ~6,5:1–10:1, texto claro sobre fundo escuro). `?v=12` → `?v=13`. tracking.js
intocado.

## Etapa 20 — Prejuízo: do bento quadrado ao spread de dados editorial (2026-09-22)

**Feedback do cliente:** o bento (Etapa 19) ficou "muito quadrado", "pacato", "não tão
moderno". Pedido: refinar mais, mais dinâmico/moderno, sem perder sobriedade.

**Diagnóstico honesto:** o bento era literalmente uma grade de retângulos arredondados
(cinco caixas). As duas células escuras do bloco B eram "cards gêmeos" e o donut + barra
fina eram exatamente o padrão progress-ring/sparkline-de-canto que lê como dashboard SaaS
(craft-floor recusa). O painel claro tinha um **vão morto** no meio. Nada comandava:
atenção diluída em cinco caixas iguais.

**Direção:** para público C-level, "moderno/dinâmico" não é mais widget — é **spread de
dados editorial** (linguagem de data-journalism, tipo FT/Bloomberg/estúdio). Dissolver as
caixas, pendurar o dado em fios (hairlines), tornar um número monumental e dar largura
real aos gráficos. Mantido o **único objeto claro** (o painel de porcelana aprovado).

**O que mudou (só apresentação; copy aprovada preservada 100%):**
- `.loss-bento`/`.loss-cell` (caixas) → **sistema `.ledger`**: dados em linhas separadas
  por hairline, sem borda-container. Leveza por espaço negativo + fio, não por retângulo.
- **Painel de porcelana** (`.loss-panel`) reescrito: conteúdo em fluxo contínuo (figura →
  fio fino → legenda), **sem o vão morto**. "R$ 180" agora monumental (serif até ~7,25rem).
- **Donut removido** → **medidor 44% largo** (`.gauge`) com escala 0→100 (ticks): lê como
  gráfico medido, não widget de canto.
- Barra fina → **semana perdida** (`.weekbar`): cinco blocos, um perdido = 1/5 = "20% da
  produtividade". Viz honesta e distinta (motivo de segmentos coerente com os 3 meses).
- Bloco B virou **duas linhas largas** (figura à esquerda, gráfico amplo + legenda à
  direita), não duas caixas lado a lado.
- Motivo de segmentos unifica a seção: 3 meses (3 segs) + semana (5 blocos, 1 cheio); o
  44% fica no medidor contínuo (variedade + coerência, sem gêmeos).

**Bug corrigido na verificação:** `.gauge__track`/`.gauge__fill` eram `<span>` inline sem
`display` → largura 0, fill invisível. Adicionado `display:block` (+ `width:100%` no fill).

**Motion:** um só momento autoral — medidor e "dia perdido" desenham na entrada via
`.is-visible` (scaleX/scaleY, nunca `width`). Estado final é o padrão (sem JS e
`prefers-reduced-motion` já aparecem preenchidos). Sem JS novo.

**Validação:** desktop 1134 e mobile 375 — grupos A e B corretos, gráficos renderizam,
leitura fluida, **0 overflow horizontal** (375=375). Detector 16: 7 low-contrast são o
falso positivo conhecido (leitura do gradiente; contraste real ~7,7:1 do texto claro
sobre o escuro), 6 radial-glow e 1 all-caps pré-existentes, 2 tight-leading das
pull-quotes (ganho de marca). Zero anti-padrão real novo — a subida 13→16 é só o mesmo
falso positivo multiplicado ao tirar o texto de dentro das células. `?v=13` → `?v=14`.
tracking.js intocado.

**Adendo — count-up nos números-chave.** O cliente pediu a Motion (React) para os
números subindo. Não instalada: projeto é estático, sem build; a Motion só roda em
bundle/React. O **conceito** (count-up on scroll) foi adaptado em **JS puro** (novo IIFE
em `main.js`): rAF + ease-out cúbico, IntersectionObserver (threshold 0), formatação
pt-BR via `toLocaleString`. Anima **R$ 180, 44% e 7,5** (pula "3 meses" — contar até 3
fica steppy; os 3 segmentos já são o movimento dele). Cada número rola enquanto seu
gráfico preenche.
- **Robustez:** o valor final vive no HTML (fonte da verdade). Sem JS → aparece correto.
  `prefers-reduced-motion` e ausência de IO/rAF → finaliza sem animar. O número só zera no
  1º frame do run() quando entra em tela (o fade-in do reveal mascara), então **nunca fica
  preso em zero** e não precisa de rede de segurança por tempo (a 1ª tentativa usava
  finalize em 4s, que matava a animação de seções profundas alcançadas após 4s — removido).
- `.countup` com `tabular-nums` para largura de dígito estável (sem tremor).
- **Verificação:** valores finais corretos (180/44/7,5) e formatação do ramp pt-BR
  conferidos (0→…→180; 0,0→…→7,5). A animação ao vivo não pôde ser observada no painel
  automatizado porque o documento fica `visibilityState:hidden`, que congela IO+rAF — roda
  normal em aba visível de usuário real. Detector 17: mesma composição de falso-positivo do
  gradiente (agora 8) + atmosfera/leading pré-existentes; zero anti-padrão real novo.
  `?v=14` → `?v=15`. tracking.js intocado.

## Etapa 21 — Bloco de autoridade: Dale Carnegie + LinkedIn (2026-09-22)

Pedido: reorganizar depoimentos e criar três seções novas depois de "Quem é João
Tufanini" — Formação Dale Carnegie, Publicações e LinkedIn — com acabamento final,
dentro do design system existente. Sem tocar em copy aprovada nem na camada funcional.

- **Reorganização (depoimentos → sobre):** já estava correta no HTML vivo
  (metodologia → depoimentos → sobre). Nada a mover. Confirmado, não fabricado.
- **Formação Dale Carnegie** (`#dale-carnegie`, após Sobre): split — trajetória à
  esquerda, certificado valorizado à direita como **artefato** (moldura matte fria +
  fio interno + realce de topo; presença por troca de superfície, não sombra difusa).
  Dados **verificados no próprio certificado** (não inventados): "Dale Carnegie
  Course® — Effective Speaking and Human Relations", "19 de fevereiro de 1990",
  "Dale Carnegie & Associates, Inc." — apresentados como `<dl>` escaneável (Programa/
  Conclusão/Emissão), não parágrafo. Legenda "Certificado original" com ícone
  verificado. Copy do título e do parágrafo preservada verbatim do brief.
  - **Divergência sinalizada ao cliente:** o certificado diz "Effective Speaking and
    Human Relations"; a credencial aprovada em *Sobre* diz "Leadership Training for
    Managers, 1990". Programas distintos. Usei o dado do certificado na seção nova
    (conforme instrução) e **não** alterei a copy aprovada de Sobre — decisão dele.
- **LinkedIn** (`#linkedin`, após onde entra Publicações; `section--raised`): split —
  convite à esquerda, **emblema de conexão** à direita (marca linear do LinkedIn ao
  centro, duas órbitas finas, três nós de rede, halo suave). Emblema decorativo
  (`aria-hidden`), some sem prejuízo. Copy (título/texto/CTA) verbatim do brief.
  - Novo ícone `#i-linkedin` no sprite: **linear**, coerente com a família (não o
    logo cheio), traço 1.5/currentColor.
  - CTA em **contorno** (`.btn--line`, novo em components.css): distinto do azul
    sólido reservado à conversão (WhatsApp), para não competir com o CTA principal.
    Link externo, `target=_blank rel=noopener`, **sem `data-cta`** (não é conversão —
    não polui `cta_section`). Os 9 CTAs de WhatsApp permanecem intactos.
- **Publicações — BLOQUEADA, aguardando o cliente.** Dois motivos: (1) o resumo único
  das duas obras veio como placeholder `[COLE AQUI...]` no brief — não invento copy;
  (2) as capas não combinam entre si nem com a página: `capa-2.png` é capa plana sobre
  **fundo branco** (2:3) e `capa-livro.jpg` é **mockup 3D** sobre quase-preto (1:1);
  ambas em dourado/amarelo (fora da paleta fria). Precisa de decisão de tratamento
  (ou assets equivalentes) + o resumo. Seção entra entre Dale Carnegie e LinkedIn.
- **Assets:** renomeados para kebab-case (convenção do projeto): `dale-carnegie.png`,
  `capa-livro.jpg`, `capa-2.png`. Nota de performance: PNGs pesados (2 MB) — otimizar
  no passe de imagens.
- **Verificação:** desktop (1280) e mobile (390) — sem overflow horizontal, botão do
  LinkedIn em 1 linha, certificado com presença em ambos. Console sem erros. Detector
  18: 8 low-contrast (todos no prejuízo, falso-positivo do gradiente), 7 radial
  (só `linkedin__halo` é novo — mesmo idioma de glow já aceito no site e o "halo suave"
  pedido), 2 leading + 1 all-caps pré-existentes. Corrigido em verificação: "ghost
  card" (fio 1px sob sombra larga) na moldura e na plaqueta — resolvido comprometendo
  com uma aresta definida OU elevação, nunca as duas. `?v=15` → `?v=18`. tracking intocado.

## Etapa 22 — Seção Publicações + troca do título do LinkedIn (2026-09-22)

- **Título do LinkedIn:** trocado de "Vamos continuar essa conversa no LinkedIn?"
  para **"Faça conexão comigo no LinkedIn"** (versão final do cliente — ele hesitou
  entre "Conheça o meu trabalho no LinkedIn" e esta, e resolveu com "ou melhor" na
  segunda). CTA e link inalterados.
- **Seção Publicações** (`#publicacoes`, entre Dale Carnegie e LinkedIn) — o cliente
  optou por seguir com os assets atuais (mesmo com a divergência que sinalizei). Composição
  editorial de **coleção**: split alternado (capas à esquerda, contexto à direita).
  - Capas como **objetos-livro** sobre o escuro: sombra de contato ancora cada uma,
    spotlight define o palco. Sem card de e-commerce, sem card duplo. `data-tilt` (mesmo
    idioma de inclinação magnética do site) nas capas.
  - **Rebalanceamento:** `capa-livro` é mockup 3D com folga escura interna (os livros
    "flutuam"); `capa-2` é arte chapada full-bleed. Para os livros baterem a mesma escala,
    `capa-livro` entra maior (desktop 21rem vs 15,5rem) e o palco usa `align-items:center`.
    Assim as duas obras ganham protagonismo equilibrado, apesar dos assets díspares.
  - **Contexto:** "Coleção Verdade Real." como lead serifado (com ícone `#i-layers` =
    coleção) + o resumo único em medida de leitura (50ch, leading 1.72). Um único resumo
    para as duas obras, sem descrição individual e sem inventar nada.
  - **Copy preservada exatamente como fornecida** (título, abertura e resumo). **Typo
    sinalizado ao cliente:** no resumo há "está série" (deveria ser "esta série");
    mantive literal por instrução explícita ("exatamente como fornecido") — correção
    aguarda o ok dele.
  - Alt text usa os títulos impressos nas próprias capas (material fornecido), para
    acessibilidade.
- **Verificação:** desktop (1280) e mobile (390) — sem overflow, capas equilibradas e
  legíveis, resumo sem virar parede de texto, transições Dale Carnegie→Publicações e
  Publicações→LinkedIn limpas. Console sem erros. Detector 18 — **zero achado novo** da
  Publicações (o spotlight do palco não foi flagueado); tudo pré-existente ou o
  falso-positivo do gradiente no prejuízo. `?v=19` → `?v=20`. tracking intocado.

## Etapa 22.1 — Publicações: capa A vira mockup (2026-09-22)

- **Troca pedida:** capa A (era `capa-2.png`, arte chapada de "O Crime e Suas Raízes")
  substituída pelo novo **mockup 3D** do mesmo livro. Renomeado `capa livro.png` →
  **`capa-crime.png`** (kebab + nome semântico; "capa livro" já era ambíguo — foi o que
  gerou a confusão). `pub-cover--a`: src → `capa-crime.png`, dimensões 1024×1536 → 1254×1254.
- **Consequência de design (boa):** agora as duas capas são mockups 3D quadrados sobre o
  escuro → par casado. CSS ajustado: ambas com a mesma escala (18,5rem base / 20rem
  desktop); comentário atualizado. Verificado: desktop = dois quadrados iguais de 277px,
  sem overflow; mobile (375) = capa A carrega e integra premium.
- **PROBLEMA sinalizado ao cliente:** o arquivo da **capa B** (`capa-livro.jpg`, mockup de
  "A Evolução Histórica do Fenômeno Criminal") **sumiu da pasta** (404) — foi removido
  quando o novo arquivo entrou. Capa B está quebrada. Nunca foi commitado (untracked), então
  não dá pra recuperar do git. Aguardando o cliente reenviar o mockup de "A Evolução".
  `pub-cover--b` mantido intocado (instrução: não mexer na outra capa).
- `capa-2.png` ficou órfão (não referenciado) — pode ser removido no passe de imagens.
- `?v=20` → `?v=21`. Copy, layout, animações e tracking intocados.

## Etapa 22.2 — Publicações: remoção da imagem quebrada (2026-09-22)

Cliente relatou imagens não aparecendo. Auditoria: **único quebrado era `capa-livro.jpg`
(capa B, 404)** — o arquivo sumiu e não voltou; todas as outras imagens da página = 200.
Como não há mais imagem para "A Evolução Histórica" (e a única outra capa disponível é do
mesmo livro "O Crime"), fiz a correção honesta: **capa B comentada** no HTML (não deletada,
para restaurar fácil) e a seção virou **composição de capa única** com `capa-crime.png`,
centralizada e maior (22rem base / 25rem desktop) para ocupar o palco com presença. Copy
(título, abertura, "Coleção Verdade Real" + resumo) preservada — o resumo fala da coleção,
lê bem com um volume representativo. Verificado: mobile 375 (capa premium, sem quebra) e
desktop 1280 (capa 400px centralizada, sem overflow); **zero imagem quebrada** (todas 200).
`?v=21` → `?v=22`. Provisório: ao reenviar o mockup de "A Evolução", restauro o par.

## Etapa 23 — Rodapé premium (contato, agendamento, unidades) + CTAs no WhatsApp oficial (2026-09-22)

- **Rodapé reestruturado** em grupos claros, mantendo o design premium:
  - **Contato** (ícone + nome + detalhe, sem URL exposta, hover discreto com realce suave —
    sem card/borda): WhatsApp (11) 99718-8324, Agendamento (Calendly), Perfil profissional
    (Oneliv), E-mail. Ordem de leitura pedida: Contato → WhatsApp → Agendamento → Perfil.
    Novos ícones lineares `#i-mail` e `#i-pin` no sprite; `#i-message`/`#i-calendar`/`#i-user`
    reaproveitados.
  - **Unidades de atendimento** — banda própria (hairline no topo), lista escaneável com pino
    (sem cards): Vila Olímpia, Interlagos, Moema, Morumbi (Market Place), na ordem e com os
    endereços exatos fornecidos. Grid 1→2→4 colunas.
  - Preservados: marca (nome + descrição), linha "Redes" (plana, sem links dados), aviso de
    emergência.
- **CTAs → WhatsApp oficial:** todos os 9 CTAs de contato migrados de `wa.me` para
  `https://api.whatsapp.com/send/?phone=5511997188324&text=...&type=phone_number&app_absent=0`.
  **Decisão sinalizada:** a URL do cliente vinha com `text` vazio; **preservei a mensagem
  pré-preenchida por seção** (mecanismo de origem de lead documentado no CLAUDE.md). Reversão
  para chat vazio é trivial se ele pedir. `data-cta`/`data-cta-section` intactos → tracking.js
  inalterado. LinkedIn, Calendly, Oneliv e navegação NÃO viraram WhatsApp.
- **Sinalizado:** removi a menção solta "Agendamento: Doctoralia, Oneliv, Calendly" (Oneliv e
  Calendly viraram links próprios; Doctoralia ficou sem link — aguardo o link se ele quiser de
  volta).
- **Verificação:** mobile 375 (rodapé completo, hierarquia limpa, sem overflow) e desktop 1280
  (DOM: sem overflow, ordem/destinos corretos). Detector 18 — zero achado novo. Load atual sem
  404 (os 404 de `capa-livro.jpg` no console eram de cargas antigas v21). `?v=22` → `?v=23`.

## Etapa 24 — Refino premium: voz tipográfica editorial + metal frio de prestígio + Publicações (par de capas) + Método (foto mais visível) (2026-09-23)

**Pedido (frontend-design):** deixar mais premium usando as referências `ref/oficial.jpeg` e
`ref/oficial 2.png` (a LEGACY) — realismo, harmonia, aspecto premium, cores secundárias
dourado + prateado, e principalmente a **tipografia dos títulos**. Corrigir Publicações para
DUAS capas (`capa-crime` + `capa 2`). Deixar a foto de fundo da seção "A ciência por trás da
alta performance" (método) **mais visível no desktop** e um pouco mais no mobile.

- **Conflito de identidade resolvido com o cliente:** a referência é dourado QUENTE; a marca do
  João é fria (azul elétrico, "sem tons quentes, dourado incluído" — CLAUDE.md). Apresentei o
  trade-off e ele escolheu **"champanhe frio + platina"**: metal dessaturado, levemente frio,
  como camada de PRESTÍGIO, nunca em CTA. Azul elétrico segue como a **única cor de ação**
  (todos os CTAs de WhatsApp) — conversão e tracking intocados.
- **Tipografia — sistema de duas vozes (como nas referências premium):**
  - Títulos de seção, hero, citações e números passam à **Cormorant Garamond** (serifada
    editorial de alto contraste), em **caixa normal** — a voz elegante. Base `h1,h2,h3` trocada
    de Cinzel-caixa-alta para Cormorant. Escala ampliada (`--step-hero`, `--step-h2`).
  - **Cinzel (caixa alta gravada)** reservada às marcas de assinatura pequenas: `.wordmark`,
    `.site-footer__name`, `.pillar__term`, `.ledger-row__term` (este ganhou `text-transform:
    uppercase` explícito ao perder o default do base). O contraste entre as duas vozes é o que
    dá o ar de estúdio.
  - Carregado Cormorant 700 (hero). IBM Plex Sans (corpo/UI) inalterada.
- **Metal frio (tokens novos em base.css):** `--champagne-hi/-/-deep`, `--platinum`,
  `--hairline-champagne`. Aplicação cirúrgica na camada de autoridade/verificação:
  filete `.rule--metal` em Sobre, Dale Carnegie e Publicações; selo + anel interno do
  certificado; ícone da "Coleção Verdade Real"; marca `#i-verified` dos depoimentos; fio do
  eyebrow do hero. Regra semântica: **credencial/autoria/verificação = metal; método/ação =
  azul**. Sem borda nas capas (evita ghost-card); anel do certificado é inset ring + sombra de
  contato (aresta definida, não borda-fina-sob-sombra-larga).
- **Publicações — par de capas restaurado:** `capa 2.jpg` renomeada para `capa-evolucao.jpg`
  (kebab-case, sem espaço na URL). Palco vira estante (base alinhada), capa A (destaque) um
  pouco maior que a B; `flex:1 1 0` + `max-width` garante que nunca estouram. Duas obras
  distintas de uma coleção — não capas gêmeas. Resumo e título preservados (typo "está série"
  mantido a pedido).
- **Método — foto mais visível:** desktop com véu ancorado à esquerda (texto) e aberto à
  direita, revelando o executivo + o pôr do sol (o único calor da página); `object-position`
  50% 42%; `text-shadow` curto só no texto para manter AA sem escurecer a foto. Mobile: banda
  maior (62svh) e véu de base mais leve.
- **Verificação:** detector 16 (8 low-contrast = falso positivo do prejuízo; 7 radial-glow =
  idioma da casa; 1 all-caps-body = rótulo/heading das credenciais, exceção que a própria regra
  admite). Os 3 achados que meu refino introduziu (oversized-h1, 2× tight-leading) foram
  corrigidos: hero desktop 74px→67px (26vh), pull-quote 1.22→1.30. Sem overflow horizontal em
  375 e 1280; sem erro de console; capas 200. `?v=23` → `?v=26`.

## Etapa 25 — Ritmo de cor (seção clara de porcelana no prejuízo), método em split nítido, hierarquia tipográfica e Instagram no rodapé (2026-09-23)

**Contexto/crítica do cliente:** a página, só em azul-escuro seção após seção, ficou "maçante, parecendo apresentação de slide, sem nenhum suspiro". As referências (LEGACY) alternam quase-preto com folhas claras de porcelana — é esse respiro que faltava. Diagnóstico: `--ink-900/850/950` estão a ~3% de luminância entre si; no código alternam, ao olho é uma laje escura contínua por 15 seções.

**Decisões:**
- **Prejuízo vira a ÚNICA seção clara** (o "suspiro"), já previsto pelos tokens `--paper*`. Estratégia DRY e isolada: redefinir `--text-100/300/400`, `--hairline*` e `--accent-bright→--accent-deep` no escopo `.section-prejuizo`, de modo que todo descendente passa a ler tinta-sobre-papel sem vazar. Azul segue o acento do dado (azul profundo para contraste no claro). Painel-âncora (R$ 180 bi) como tile branco elevado (sombra de contato, sem borda — não é ghost card). Vinheta topo/base assada no `background-image` (sem `box-shadow` na seção, senão o detector lê a seção como card e acusa card-dentro-de-card). Figura do painel reduzida a 6rem (teto de display).
- **Método em split no desktop:** a foto (`gestalt-metodo.jpg`, fonte 820×1024) era esticada full-bleed ~1,7× e ficava mole sob o véu. Agora ancorada à direita (56%), renderizada a ~711px = perto do nativo → NÍTIDA; texto à esquerda sobre escuro sólido, sem véu por cima. É a composição das referências (sujeito emerge do escuro). Mobile: banda 62→66svh, véu de base mais leve — foto um pouco mais visível.
- **Tipografia:** `--step-h2` 3,15→3,4rem (títulos mais dominantes), `--step-lead` min 1,15→1,2rem (degrau mais claro sobre o corpo), `letter-spacing -0.01em` nos títulos de seção. Corpo intacto (não vira legenda no celular).
- **Rodapé:** placeholder textual "Redes: ..." substituído por grupo Instagram real com o componente `.footer-link` e novo glyph `#i-instagram` (traço 1.5). Duas contas: Conexão em Mente (@conexaoementepsico) e UNA — Uma Verdade Real (@unaverdadereal, token `stkn` de rastreio removido do link).

**Verificação:** detector 16 (todos conhecidos/aceitos; `nested-cards` resolvido; os 9 `low-contrast` são falso-positivo do prejuízo — texto `--paper-ink` mede 14:1 real sobre `--paper`). Sem overflow horizontal a 375 e 1280. Split do método confirmado a 711px (downscale). Rodapé com as duas contas corretas.

**Pendências sinalizadas:** o 3º Instagram (perfil pessoal do João) não foi adicionado — o cliente colou o link da Conexão em Mente duas vezes; aguarda o handle pessoal correto.

## Etapa 26 — Instagram pessoal do João, otimização de peso (imagens −4,4MB, fontes enxutas), reveal mais fluido e auditoria responsiva (2026-09-23)

**Pedido:** adicionar o Instagram pessoal do João (@psijoaotufanini — ele havia mandado o da Conexão em Mente duas vezes); corrigir bugs de responsivo (principalmente mobile, o principal do Google Ads) e de desktop; deixar mais fluido, leve e otimizado; imagens carregando normalmente (algumas demoravam); e mais respiro/harmonia de cor se necessário.

**Decisões:**
- **Instagram pessoal:** 3ª conta no rodapé (João Tufanini @psijoaotufanini), como primeira do bloco. Agora são três: João, Conexão em Mente, UNA.
- **Peso das imagens (a causa real do "demora a carregar"):** `capa-crime.png` 2,28MB e `dale-carnegie.png` 2,13MB eram ~5× maiores que o tamanho de exibição. Convertidas para JPG no tamanho certo (retina): capa-crime 2,28MB→113KB (640²), dale-carnegie 2,13MB→306KB (1200×928), capa-evolucao 476KB→73KB (560²). Total de imagens 4,88MB→492KB (−90%). `width/height` atualizados para as novas dimensões (mesma proporção, sem layout shift). Os PNGs originais ficam em disco, sem referência.
- **Fontes enxutas:** auditoria de uso real → Cinzel só peso 600 (500/700 não usados; `.site-footer__name` fixado em 600); Cormorant sem o romano 500 (não usado); `.pub__collection` de itálico 600 (que nem era carregado) para 500 (itálico carregado). Três arquivos de fonte a menos.
- **Fluidez:** removido o `filter: blur()` do reveal de rolagem (animar blur em vários elementos escalonados trepida no mobile) — mantido opacity + translateY, duração 0,85→0,7s. Reveals mais leves e diretos.
- **Cor/respiro:** mantido o ritmo da Etapa 25 (a folha clara do prejuízo é o respiro estrutural; foto do método e capas/certificado dão variação no restante). Não forçei uma segunda seção clara para não diluir nem arriscar novos bugs às vésperas da aprovação — deixado como opção.

**Verificação:** detector 16 (mesmos conhecidos/aceitos, sem regressão). Sem overflow horizontal a 360, 768, 1024, 1280 (o único item acusado, `metodo__img`, é o zoom do parallax recortado por `overflow:hidden`, não gera scroll). As três imagens otimizadas carregam (naturalWidth 1200/640/560). Hero, diferença, publicações e rodapé conferidos a 360; split do método conferido a 1024. Fontes sem renderização sintética.

## Etapa 27 — Metodologia: payoff em destaque + ícones dos pilares em metal (2026-09-23)

**Pedido:** o enunciado "Três pilares que transformam a Gestalt em lucro e retenção" estava pequeno demais (usava --step-h3, o menor heading) e passava despercebido; deixá-lo destacado, efeito à vontade. E os ícones dos pilares (cadeado/coração/ferramenta) em prateado ou dourado, para variar a cor.

**Decisões:**
- **Payoff destacado:** de `--step-h3` (máx 24px) para `clamp(1.6rem, 1.5vw + 1.1rem, 2.35rem)` (mobile 25,6px, desktop 36,8px), medida 26ch, tracking -0.01em. Efeito: filete de champanhe centrado acima (`::before`), amarrando ao metal dos ícones. Fica abaixo do título da seção (que segue maior, com fio azul) — hierarquia preservada.
- **Ícones dos pilares em champanhe:** `.pillar__icon` do azul para o metal frio de prestígio (badge + ícone no mesmo champanhe). Atende ao pedido de variar a cor sem dourado quente (proibido na marca), coerente com o selo do certificado e a coleção. Statements dos pilares e a interação (glow/fio azul) da seção permanecem azuis — método/ação segue azul.

**Verificação:** detector sem regressão. Sem overflow a 375 e 1280. Ícones confirmados em champanhe (rgb 220,204,163); payoff 36,8px desktop / 25,6px mobile.

## Etapa 28 — Prejuízo: reversão da folha clara para o dark integrado (2026-09-23)

**Pedido:** tirar o branco da seção "O prejuízo silencioso" — a quebra total para o claro (Etapa 25) ficou abrupta demais. Voltar ao dark como estava antes; usar a cor de um jeito mais secundário para ficar mais fluido.

**Decisões:**
- **Seção volta ao dark** (ink-950 + halo azul discreto). Removidas todas as redefinições locais de token da Etapa 25 — descendentes voltam a ler claro-sobre-escuro pelos tokens globais.
- **Painel do dado NÃO volta à porcelana branca** (ainda seria "branco"): integrei ao dark como os demais cards (compare/pilares/depoimentos) — `linear-gradient(ink-800, ink-850)` + fio, fio de topo (uma elevação só, sem ghost card). O número "R$ 180" segue gigante em claro; a cor mora no acento (unidade e fio interno em azul), não no fundo. Mais fluido, sem superfície clara.
- Internos do painel recoloridos para o dark: figura → text-100, unidade → accent-bright, fio interno → hairline-accent (azul, cor secundária), corpo → text-400.

**Verificação:** sem overflow a 375 e 1280. Seção confirmada em ink-950, figura em text-100. A folha clara e a exceção de baixo-contraste que ela gerava no detector deixam de existir.

## Etapa 29 — Remoção do aviso de emergência do rodapé (2026-09-23)

**Pedido:** remover o bloco "Em caso de emergência ou risco à vida... CVV 188... SAMU 192... CAPS..." do rodapé.

**Decisão:** removido o `<div class="shell"><p class="site-footer__notice">` do rodapé. A regra CSS `.site-footer__notice` foi mantida (sem uso, custo zero) para restauração trivial. Rodapé passa a encerrar no bloco de unidades.

**Ressalva registrada:** sinalizei ao cliente que, por ser site de psicólogo (CRP) e a página tratar de burnout/saúde mental, esse aviso costuma ser recomendado por ética profissional — sugeri validação com o João (responsável técnico). Decisão do cliente, reversível numa linha.

## Etapa 30 — Performance: WebP + fontes auto-hospedadas (tráfego pago) (2026-09-23)

**Pedido:** otimizar velocidade — imagens demorando e site lento na primeira abertura. É Google Ads, precisa ser rápido, sem gargalo.

**Diagnóstico (medido):** o gargalo de "primeira abertura" era as fontes externas — 1 CSS render-blocking do googleapis + handshakes para gstatic no caminho crítico. Imagens já otimizadas na Etapa 26, mas ainda em JPG.

**Decisões:**
- **Fontes auto-hospedadas** (planejado no CLAUDE.md): baixados os woff2 (subconjunto latino, cobre todo o PT-BR) e servidos do próprio domínio. Cormorant e IBM Plex são variáveis — 1 arquivo por família cobre os pesos (`font-weight: 600 700` e `400 600`); 4 arquivos únicos, 122KB total. `@font-face` em base.css, `display:swap`. Removidos os `<link>` do Google Fonts e os preconnects. Precarregadas as 2 faces acima da dobra (Cormorant do título, IBM Plex do corpo). Zero requisição externa de fonte (confirmado).
- **Imagens em WebP** (Pillow): as 6 imagens em uso convertidas a partir das fontes de melhor qualidade. Total 717KB→313KB (−56%); hero/LCP 59KB→35KB; certificado 306KB→106KB. `width/height` mantidos (sem layout shift). JPG/PNG antigos ficam em disco, sem referência.

**Verificação:** 0 requisições a googleapis/gstatic; 4 woff2 same-origin carregados; document.fonts=loaded; hero.webp (765px) ok; título do hero em Cormorant 700; sem erro no console; detector sem regressão. Sem overflow.

## Etapa 31 — Ajustes finais: Calendly explícito, "Conexão & Mente", endurecimento iOS (2026-09-30)

**Pedido:** revisão de bugs/performance/peso; 100% responsivo em iOS (iPhone 11–18); adicionar link do Calendly no rodapé; trocar o conector de "Conexão e Mente" para o "e comercial" (&).

**Decisões:**
- **Calendly:** o link já existia no rodapé (desde a Etapa 23), rotulado "Agendamento". Renomeado para **"Calendly" / "Agende um horário"** (mesma URL contato-inicial), deixando explícito — não dupliquei.
- **"Conexão & Mente":** rótulo do Instagram trocado de "em Mente" para "& Mente" (`&amp;`).
- **Endurecimento iOS:** `-webkit-tap-highlight-color: transparent` (tira o flash cinza no toque; os CTAs têm :active próprio). Fallback `vh` antes de todo `svh` (body, hero, hero-grid, método) para iOS < 15.4. Prefixos `-webkit-` de backdrop-filter e backface-visibility já presentes; parallax/tilt já desligados em ponteiro grosso (toque) — sem jank no mobile.
- **Performance:** já otimizada na Etapa 30 (WebP 313KB lazy, fontes self-hosted 122KB com 2 precarregadas, hero/LCP 35KB preload, JS deferido). Nada novo a cortar; revisão não achou gargalo.

**Verificação:** sem overflow horizontal a 375/390/430; rótulos "Conexão & Mente" e "Calendly" confirmados no DOM e no render; sem erro no console; detector sem regressão. Simulador iOS real indisponível (Mac sem Xcode completo) — informado ao cliente.

# Copy aprovada — Site João Tufanini

Fonte da verdade do projeto. Nenhuma palavra muda sem aprovação.

---

## Seção 1 — Hero

**Linha de contexto:** Para empresas e para líderes

**Título:** Lidere com alta performance sem esgotar sua equipe

**Complemento:** Mentoria estratégica para CEOs e executivos

**Apoio:** Método estratégico baseado na Gestalt para alcançar resultados extraordinários protegendo a saúde mental e organizacional da sua empresa.

**Botão:** Quero alta performance

**Abaixo do botão:** Clique para agendar um diagnóstico estratégico

**Credenciais:** 22 anos de atuação · CEO da Clínica Íntegra · CRP 06/72.409 · Dale Carnegie

---

## Seção 2 — Cenários

**Título:** Você identifica algum destes cenários?

1. Acorda às 3 da manhã com a pauta do dia seguinte na cabeça.
2. Sente que não consegue parar, que não pode parar, mesmo muito cansado.
3. Já perdeu a conta de quantas vezes cancelou algo em casa por causa do trabalho.
4. Sente que precisa estar em tudo para garantir que nada saia errado.
5. Determinados atritos no time drenam sua energia inteira.
6. O corpo começa a cobrar: insônia, coluna, tensão muscular, exaustão extrema.
7. Se pergunta, mais vezes do que gostaria, se está dando conta de tudo.
8. Muitos assuntos ao mesmo tempo, com a sensação de não ter feito nada ao fim do dia.
9. Sente que ninguém entende de verdade o que é liderar e sente-se só às vezes.
10. Vive no automático e fora do trabalho não sabe nem mais do que gosta.

**Fechamento:** Invista na sua estrutura psicológica.

**Botão:** Quero agendar um diagnóstico

> Nota estrutural: estes dez itens são cenários paralelos, não uma sequência. Não numerar com 01/02/03.

---

## Seção 3 — Prejuízo

**Título:** O prejuízo silencioso

**Subtítulo:** Quanto custa ignorar o burnout e a má comunicação?

**Apoio:** O esgotamento e os ruídos de comunicação não destroem apenas o clima da sua empresa. Eles corroem diretamente a sua margem de lucro.

### Bloco A — O verdadeiro custo do burnout no Brasil

**R$ 180 bilhões por ano** — prejuízo estimado do esgotamento dos colaboradores para as empresas brasileiras em perda de produtividade, retrabalho e absenteísmo, segundo a ISMA-BR.

**3 meses** — tempo médio de afastamento de um colaborador qualificado por licença médica por transtornos psíquicos.

**NR-1 e PGR** — com a inclusão obrigatória de riscos psicossociais no PGR, o esgotamento profissional virou risco de autuação e passivo jurídico.

### Bloco B — O ralo financeiro da má comunicação

**44% dos projetos corporativos** falham ou geram custos extras por falta de clareza e sinergia entre lideranças e equipes.

**7,5 horas por semana** perdidas por colaborador esclarecendo metas e corrigindo mensagens mal interpretadas, o equivalente a 20% da produtividade.

**Destaque:** "Proteger o capital emocional e social do seu negócio não é caridade. É inteligência financeira."

---

## Seção 4 — Diferença

**Título:** Por que a Gestalt é diferente de tudo que você já viu no mundo corporativo

**Apoio:** Se você acha que terapia é apenas para tratar problemas individuais no divã, você está prestes a descobrir a ferramenta de gestão mais poderosa do mercado atual.

### O mito da terapia tradicional

**Foco no passado** — investigar traumas de infância dos colaboradores.
**Passiva e lenta** — longas conversas sem direcionamento claro ou prazo.
**Apenas individual** — trata a pessoa isolada do ambiente em que ela vive.

### A realidade da Gestalt aplicada aos negócios

**Foco no presente** — diagnosticar gargalos de comunicação e processos que travam a equipe hoje.
**Prática e estratégica** — intervenções dinâmicas que geram consciência rápida e mudam comportamentos na hora.
**Visão sistêmica** — ajusta a relação entre líder, colaboradores e cultura para que o ecossistema produza mais.

**Destaque:** "Não estamos falando de tratar o indivíduo isolado, mas de otimizar a engrenagem humana que move o seu faturamento."

---

## Seção 5 — Método

**Título:** A ciência da alta performance

**Subtítulo:** O que é a Gestalt no contexto corporativo?

Para o mundo corporativo, a Gestalt não é um tratamento clínico, mas uma ciência das relações, da percepção e do comportamento. O termo vem do alemão e significa "forma" ou "todo".

Em vez de olhar para os funcionários isolados, a Gestalt enxerga a empresa como um ecossistema vivo. Estuda como líderes e liderados interagem, como percebem os problemas e como a cultura molda o rendimento de todos.

O foco está no aqui e agora: resolver conflitos atuais, melhorar a comunicação presente e gerar tomadas de consciência imediatas para destravar a produtividade.

---

## Seção 6 — Entregável

**Título:** O que sua equipe vai aprender na prática

**Apoio:** Mais do que teoria, uma imersão prática baseada na Gestalt que transforma o comportamento, a maturidade e a entrega dos seus profissionais no dia a dia.

**Presença e foco no resultado** — Sua equipe abandona a ansiedade sobre o futuro e a busca por culpados do passado para resolver os problemas reais do presente.

**Protagonismo e autonomia** — O colaborador entende suas escolhas e as consequências nos resultados. Decide com mais segurança e menos dependência do líder.

**Comunicação clara, sem ruídos** — O fim dos ruídos, da rádio-peão e dos conflitos silenciosos que destroem o clima organizacional.

**Visão sistêmica e responsabilidade ativa** — Cada colaborador entende o impacto direto do seu trabalho no resultado global. Sinergia real, não discurso.

**Inteligência emocional e sustentabilidade** — Capital emocional para resistir à pressão do mercado e identificar os primeiros sintomas de estresse crônico antes que virem burnout.

**Botão:** Quero destravar a performance da minha equipe

---

## Seção 7 — Metodologia

**Título:** Metodologia da Gestalt

**Apoio:** Pautada nos três pilares do lucro sustentável.

### Sigilo absoluto
**O que entra aqui, não sai. Nunca.**
Total liberdade para falar sobre a empresa, o time, o board e decisões estratégicas que mais ninguém pode saber.
*Nota: líderes escolhem o atendimento estritamente particular.*

### Acolhimento real
**Zero julgamentos ou cobranças.**
Você já vive sob pressão externa diária. Este é o único lugar onde pode desarmar, chegar cansado e não precisar performar.
*Nota: um espaço seguro de descompressão para lideranças.*

### Foco prático
**Não é apenas falar sobre emoções.**
O processo é desenhado para o ambiente corporativo. Você entra com um problema e sai com ferramentas práticas de resolução.
*Nota: mentoria com foco em ação e clareza mental.*

**Subtítulo:** Como a Gestalt aplicada resolve o retrabalho, o burnout e a falta de protagonismo em grandes corporações.

**Título:** Três pilares que transformam a Gestalt em lucro e retenção

**Consciência coletiva** — sua equipe passa a enxergar com clareza os pontos cegos que geram retrabalho, conflitos e desperdício de energia.

**Responsabilidade ativa** — líderes e liderados deixam a postura de culpabilização e assumem o protagonismo na resolução de problemas práticos.

**Contato saudável** — redução imediata de ruídos na comunicação interna, diminuindo o estresse crônico e o turnover.

**Botão:** Quero destravar a performance da minha equipe

---

## Seção 8 — Depoimentos

**Título:** O que dizem quem já passou por aqui

**J.G., junho de 2026**
A abordagem dele transmite muita segurança, criando um ambiente confortável e livre de julgamentos. Sua condução demonstra profunda sensibilidade e competência técnica para pontuar as questões certas no momento adequado.

**S.B., maio de 2026**
Foi um dos investimentos mais importantes que fiz em mim mesmo. A comunicação é clara e direta, o que torna o processo objetivo e produtivo. Superei períodos difíceis e ganhei confiança real nas minhas decisões.

**S.S.C., maio de 2026**
O Dr. João tem sido um profissional muito atencioso, me ajudando tanto nas questões profissionais quanto pessoais e familiares. Me sinto muito à vontade para falar e me entender como pessoa.

**Rodapé da seção:** verificados no Doctoralia

---

## Seção 9 — Sobre

**Título:** Quem é João Tufanini

**Subtítulo:** A união exata entre a psicologia de alta performance e a realidade do ambiente corporativo

Diferente de terapeutas com formação exclusivamente teórica, João construiu sua bagagem dentro do ecossistema de alta pressão.

Iniciou no ambiente comercial como vendedor aos 16 anos e escalou até assumir a diretoria comercial dos negócios da família. Foi essa vivência nas dores do mercado que moldou sua transição para a psicologia clínica.

Seja no board de uma grande empresa, nos boxes de uma competição automobilística ou em atendimentos de alta confidencialidade, sua missão é clara: transformar pressão em performance e conflito em lucro sustentável.

### Credenciais
- Psicólogo, CRP 06/72.409
- Pós-graduado em Investigação Criminal e Criminologia
- Graduate Dale Carnegie, Leadership Training for Managers, 1990
- CEO da Clínica Íntegra
- Especialista em riscos psicossociais, NR-1, gestão de conflitos e burnout
- Mentor de pilotos e equipes de rally profissional

**Botão:** Quero agendar um diagnóstico

---

## Seção 10 — Publicações

**Título:** Publicações

**Apoio:** Textos e reflexões sobre liderança, gestão de conflitos, saúde mental no trabalho e desenvolvimento humano.

Quatro entradas. Títulos reais ainda não definidos — usar placeholders coerentes com os temas e marcar no HTML que serão substituídos.

**Botão:** Ver todas as publicações

---

## Seção 11 — Parceiros

**Título:** Apoio e parceiros

**Apoio:** Empresas apoiadoras da Clínica Íntegra e parceiros comerciais.

Quantidade final de logos indefinida. Projetar para cinco, com arranjo tolerando de três a oito.

---

## Seção 12 — LinkedIn

**Título:** Conecte-se comigo no LinkedIn

**Apoio:** Reflexões semanais sobre liderança, performance e comportamento organizacional.

Três entradas de post. Conteúdo real entra depois.

**Botão:** Acessar perfil no LinkedIn

---

## Seção 13 — Conversão

**Título:** Seu diagnóstico estratégico pode ser esta semana

**Apoio:** 22 anos de método clínico aplicados à realidade corporativa. Alta performance sem esgotar sua equipe.

**Botão:** Quero alta performance

---

## Seção 14 — FAQ

**1. Preciso ter um problema sério para buscar a mentoria?**
Não. Muita gente procura para desenvolver clareza, tomar decisões grandes com mais segurança, ou simplesmente para ter um consultor do lado no dia a dia. Mentoria não é só para a crise. É também, e principalmente, para quem quer liderar com maior segurança.

**2. Quanto tempo dura cada sessão? São semanais ou quinzenais?**
50 minutos, com frequência semanal ou quinzenal de acordo com a avaliação técnica.

**3. Presencial ou online?**
Os dois. Presencial em São Paulo, online para qualquer lugar do Brasil ou do exterior. Também há atendimento domiciliar e hospitalar quando faz sentido.

**4. Vocês atendem por convênio?**
Não. Apenas atendimento particular, com continuidade do mesmo profissional do começo ao fim.

**5. Vocês atendem 24 horas?**
Sim, temos plantão 24 horas.

**6. Quanto custa uma sessão?**
O valor é informado no primeiro contato, considerando modalidade e frequência. Fale conosco pelo WhatsApp.

**7. Vocês prescrevem medicação?**
Não. Prescrição é competência exclusiva de médicos. Quando a situação pede acompanhamento medicamentoso, indicamos um psiquiatra e trabalhamos em parceria.

**8. Quanto tempo dura o processo?**
Depende do que você trouxe e do que você quer. Alguns processos são pontuais, focados em resolver algo específico. Outros são de acompanhamento contínuo.

**9. A empresa saberá que eu vim? Como funciona o sigilo?**
Não. O sigilo é regido pelo Código de Ética do CRP.

**10. O que diferencia a Gestalt de outras abordagens?**
A Gestalt se diferencia pela perspectiva holística, pelo foco absoluto no momento presente e pelo uso de métodos experienciais.

---

## Seção 15 — Contato e rodapé

**Fechamento:** Sua dúvida não foi respondida?

**Apoio:** Se ficou alguma coisa no ar, é só me chamar direto. Respondo pessoalmente.

**Botão:** Falar no WhatsApp

### Rodapé

João Tufanini, psicólogo, CRP 06/72.409

Mentoria estratégica baseada na Gestalt para CEOs, executivos e empresas que buscam alta performance sem esgotar suas equipes.

- WhatsApp: (11) 99718-8324
- E-mail: psijoaotufanini@gmail.com
- Agendamento: Doctoralia, Oneliv, Calendly
- Redes: LinkedIn, Instagram, Facebook, YouTube

### Aviso obrigatório

Exigência ética do Conselho Federal de Psicologia. Precisa estar legível, não escondido.

Em caso de emergência ou risco à vida, procure ajuda imediatamente. CVV 188, ligação gratuita 24 horas. SAMU 192. Procure o CAPS mais próximo. Este site não substitui atendimento de urgência.
